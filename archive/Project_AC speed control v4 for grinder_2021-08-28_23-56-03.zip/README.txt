Speed control for grinder with BackEMF (sensorless) RPM tracking. Currently PCBs available for Newacalox and BDCat models.

> **Follow to github: https://github.com/speedcontrols/ac_sc_grinder for documentation and firmware. This page is for PCB and components order only.**

[![](https://live.staticflickr.com/65535/51349909038_5d22afb5a4_q.jpg)](https://flic.kr/p/2meBGXh) [![](https://live.staticflickr.com/65535/51350422999_bb2b404f7c_q.jpg)](https://flic.kr/p/2meEkJF) [![](https://live.staticflickr.com/65535/51348952562_a89ed0cca9_q.jpg)](https://flic.kr/p/2mewNCj) [![](https://live.staticflickr.com/65535/51350702150_fa9de85cbd_q.jpg)](https://flic.kr/p/2meFLHC)            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。