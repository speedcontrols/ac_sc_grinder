Speed control for grinders with BackEMF (sensorless) RPM tracking. This PCB is for [Hilda 180W](https://www.aliexpress.com/wholesale?SearchText=hilda+180w).

> Follow to github: https://github.com/speedcontrols/ac_sc_grinder for documentation and firmware. This page is for PCB and components order only.

[![](https://farm2.staticflickr.com/1761/41339534500_7e22875ff7_m.jpg)](https://flic.kr/p/25Z2VmQ)            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。